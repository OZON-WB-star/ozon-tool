@echo off
start "" "%~dp0start-backend.bat"
timeout /t 4 >nul
start "" "%~dp0start-frontend.bat"
