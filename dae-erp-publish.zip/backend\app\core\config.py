from pydantic import BaseModel, Field


class Settings(BaseModel):
    app_name: str = "Dae ERP API"
    environment: str = "production"
    allow_origins: list[str] = Field(default_factory=lambda: ["*"])
    allow_credentials: bool = False


settings = Settings()
