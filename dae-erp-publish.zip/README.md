# 大鹅ERP 可发布包

这个目录已经整理成可直接部署的发布版本：

- `frontend/`
  前台静态站点，可直接上传到 Nginx、宝塔、Vercel、Netlify，或任何静态站点空间。
- `backend/`
  FastAPI 后端，可部署到云服务器、Docker、宝塔 Python 项目，或本地测试环境。

## 你只需要改 1 个地方

打开：

- `frontend/assets/config.js`

把里面的地址改成你的真实后端地址，例如：

```js
window.DAE_API_BASE_URL = "https://api.your-domain.com";
```

## 本地测试

1. 先启动后端
   运行 `start-backend.bat`
2. 再启动前端静态站点
   运行 `start-frontend.bat`
3. 打开浏览器访问
   `http://127.0.0.1:8080`

## 服务器部署建议

### 方案 A：前后端分开部署

- 前端上传 `frontend/` 全部文件到静态站点
- 后端上传 `backend/` 到 Python 服务器
- 修改 `frontend/assets/config.js` 为后端线上地址

### 方案 B：同域部署

- 前端放在主域名，例如 `https://daeerp.com`
- 后端放在同域反向代理，例如 `https://daeerp.com/api`
- 这时可以把 `frontend/assets/config.js` 改成：

```js
window.DAE_API_BASE_URL = "";
```

或直接写主域名。

## 目录说明

- `frontend/index.html`
  前台首页入口
- `frontend/admin/index.html`
  后台首页入口
- `backend/app/main.py`
  FastAPI 启动入口
- `backend/requirements.txt`
  后端依赖

## 当前版本说明

这是“可发布测试版”：

- 页面可直接打开使用
- 前端可脱离后端回退到演示数据
- 后端为演示 API 骨架，方便你先部署、联调、验页面
- 后续可以继续替换成真实数据库和 Ozon 正式接口
